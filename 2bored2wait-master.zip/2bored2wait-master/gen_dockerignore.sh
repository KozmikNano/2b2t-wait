#!/bin/sh
cat .gitignore dockerignore_template > .dockerignore
